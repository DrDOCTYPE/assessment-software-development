# Prompts Used for Sign In Form Project

## 1. Creating the HTML structure
**Prompt Example:**
> "Generate a responsive sign-in page with username, password, terms checkbox, and Google sign-in button."

**Why I used it:**
To quickly create a structured HTML skeleton for the Sign In form without starting from scratch.

**What it solved:**
Saved time on basic layout, ensured semantic HTML, and gave a foundation for styling and scripting.

---

## 2. Styling the Sign In page with CSS
**Prompt Example:**
> "Write CSS to style a sign-in form with a card layout, left-side image section, and right-side form section. Make it responsive for mobile and desktop."

**Why I used it:**
To apply modern styling practices and make the page visually appealing.

**What it solved:**
Provided professional-looking design, proper spacing, responsiveness, and a clear visual hierarchy.

---

## 3. Incorporating icons and images
**Prompt Example:**
> "Add a Google icon button for social sign-in and include a placeholder image for the left section of the card."

**Why I used it:**
To enhance UI/UX and make the sign-in page more realistic and user-friendly.

**What it solved:**
Improved visual appeal and gave a template for adding third-party sign-in options.

---

## 4. Responsive adjustments
**Prompt Example:**
> "Make the sign-in page responsive, stacking the image section on top and the form below for screens smaller than 768px."

**Why I used it:**
To ensure the page works well on mobile devices.

**What it solved:**
Prevented layout breaking on small screens and ensured accessibility.

---