# Mobius | Sign In Form

## Purpose
This project is a beginner-level **Sign In page** designed to practice front-end web development.
The page allows users to:
- Enter a username and password
- Accept terms and conditions
- Sign in using a placeholder "Google Sign In" button
It focuses on **responsive design, form validation, and user interface layout**.

---

## Technologies Used
- **HTML5**: For page structure
- **CSS3**: For styling and responsive design
- **Assets**: Images and icons (e.g., `Mobius.ico`, illustration PNG)

---

## How to Run
1. **Clone or download the project** to your local machine.
2. Open the folder and locate the `index.html` file:
   ```text
   beginner/projects/project-name/index.html
3. Extract the Fonts!.zip archive and install all the respective fonts.
