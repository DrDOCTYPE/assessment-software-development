# Learning Notes – Beginner Track

## Project: Mobius | Sign In Form

### 1. What I Learned
- **HTML Structure**:
  Learned how to structure a form using semantic HTML tags (`<form>`, `<label>`, `<input>`), grouping sections, and using placeholders effectively.

- **CSS Styling & Layout**:
  - Applied **Flexbox** to create a responsive two-column layout.
  - Learned to style buttons, inputs, and checkboxes consistently.
  - Implemented a **responsive design** using media queries for mobile screens.
  - Added shadows, border-radius, and hover effects for a modern UI.

- **JavaScript Interactivity**:
  - Learned to validate form inputs and display **success or error messages**.
  - Handled checkbox validation for terms and conditions.
  - Practiced DOM manipulation (`document.getElementById`, `addEventListener`).

- **Project Organization**:
  - Understood the importance of separating **src**, **assets**, **documentation**, and **prompts**.
  - Practiced creating `README.md` for projects and documenting learning and prompts.

---

### 2. Challenges Faced
1. **Responsive Design Issues**:
   - Initial layout broke on small screens.
   - Images and form sections overlapped.

2. **Form Validation Logic**:
   - Needed to ensure that both username/password and terms checkbox were validated.
   - Displaying dynamic messages (success/error) was tricky.

3. **Asset Linking**:
   - Paths to images (`assets/`) were sometimes incorrect, causing broken images/icons.

---

### 3. How I Solved the Challenges
1. **Responsive Design**:
   - Used **media queries** for screens below 768px.
   - Stacked image and form sections vertically on small devices.

2. **Form Validation**:
   - Added `required` attributes in HTML inputs.
   - Used JavaScript `addEventListener('submit', ...)` to prevent default submission and show messages dynamically.

3. **Asset Linking**:
   - Ensured correct relative paths based on folder structure.
   - Double-checked that images and icons were in `assets/` folder.

---

### 4. Key Takeaways
- Structuring files and folders correctly from the beginning prevents confusion later.
- Separating **HTML, CSS, JS, and assets** makes projects easier to manage.
- Documenting prompts, solutions, and challenges helps **track learning progress**.
- Responsive design requires testing on multiple screen sizes.
- Even beginner-level projects teach **problem-solving, debugging, and attention to detail**.

---

### 5. Next Steps
- Practice **more form validation scenarios** (e.g., regex for email/password strength).
- Explore **CSS frameworks** (Bootstrap/Tailwind) for faster styling.
- Start **Intermediate Track projects** with multi-page apps or simple backend integration.

---